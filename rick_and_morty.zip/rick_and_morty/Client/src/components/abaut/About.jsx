const Abaut = () => {
    return(
        <div>Hola</div>
    )
}

export default Abaut